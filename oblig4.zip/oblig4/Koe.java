public class Koe <E> extends Lenkeliste <E> {
    /* Trenger ikke å redefinere noen metoder ettersom Lenkeliste
     * allerede har de egenskapene vi er ute etter:
     * - Siste element som blir lagt til skal bakerst i listen
     * - Første element blir fjernet først
     */
}
