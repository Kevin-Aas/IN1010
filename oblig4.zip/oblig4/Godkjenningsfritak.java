interface Godkjenningsfritak {
    String hentKontrollkode();
}